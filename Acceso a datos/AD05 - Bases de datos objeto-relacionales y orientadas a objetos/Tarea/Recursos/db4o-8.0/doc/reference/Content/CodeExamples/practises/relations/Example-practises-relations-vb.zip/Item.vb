﻿Namespace Db4oDoc.Code.Practises.Relations

    Class Item

    End Class

End Namespace
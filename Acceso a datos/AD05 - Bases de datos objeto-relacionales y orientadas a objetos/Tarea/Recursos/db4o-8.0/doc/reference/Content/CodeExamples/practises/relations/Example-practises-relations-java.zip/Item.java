package com.db4odoc.practises.relations;


class Item {
}

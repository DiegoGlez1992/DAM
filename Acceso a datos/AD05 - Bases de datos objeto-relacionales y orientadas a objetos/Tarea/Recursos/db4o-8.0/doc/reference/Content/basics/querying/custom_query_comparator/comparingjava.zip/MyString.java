/* Copyright (C) 2007 db4objects Inc. http://www.db4o.com */
package com.db4odoc.comparing;

class MyString {

	private String _string;

	public MyString(String string) {
		_string = string;
	}

	public String toString() {
		return _string;
	}
}
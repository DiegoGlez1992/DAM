Imports Db4objects.Db4o
Imports Db4objects.Db4odoc.Web.Data


Namespace Db4objects.Db4odoc.Web
    Partial Class _Default
        Inherits System.Web.UI.Page

        Private Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        End Sub

        Public Shared Function RetrieveAll() As IList
            Return Db4oHttpModule.Client.Get(GetType(Message))
        End Function
        ' end RetrieveAll

        Public Shared Sub DeleteAll()

            Dim messages As IList = Db4oHttpModule.Client.Get(GetType(Message))
            For Each msg As Message In messages
                Db4oHttpModule.Client.Delete(msg)
            Next

        End Sub
        ' end DeleteAll

        Public Shared Sub SaveMessage(ByVal username As String, ByVal text As String)

            Dim msg As Message = New Message(username, text)
            Db4oHttpModule.Client.Set(msg)
        End Sub
        ' end SaveMessage

        Public Sub ButtonGet_Click(ByVal s As Object, ByVal e As EventArgs)
            entries.InnerHtml = ""
            Dim list As IList = RetrieveAll()
            For Each msg As Message In list
                entries.InnerHtml = "<hr>" + msg.ToString() + entries.InnerHtml
            Next
        End Sub
        ' end ButtonGet_Click

        Public Sub ButtonSet_Click(ByVal s As Object, ByVal e As EventArgs)
            SaveMessage(username.Value, Message.Value)
            username.Value = ""
            Message.Value = ""
        End Sub
        ' end ButtonSet_Click

        Public Sub ButtonClear_Click(ByVal s As Object, ByVal e As EventArgs)
            DeleteAll()
            entries.InnerHtml = ""
        End Sub
        ' end ButtonClear_Click
    End Class

End Namespace

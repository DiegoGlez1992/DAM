package com.db4odoc.inconsistent;

public class Pilot {

	private String name;
	
	public String getName() {
		return name;
	}

	public Pilot(String name) {
		this.name = name;
	}
	
	public String toString(){
		return name;
	}
	
}
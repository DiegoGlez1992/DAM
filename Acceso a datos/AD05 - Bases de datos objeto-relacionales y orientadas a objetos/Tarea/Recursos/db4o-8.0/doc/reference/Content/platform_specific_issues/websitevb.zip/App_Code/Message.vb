Imports System
Namespace Db4objects.Db4odoc.Web.Data

    Public Class Message
        Private _text As String
        Private _username As String

        Public Sub New(ByVal username As String, ByVal text As String)
            _username = username
            _text = text
        End Sub

        Public Property Text() As String
            Get
                Return _text
            End Get
            Set(ByVal value As String)
                _text = value
            End Set
        End Property

        Public Overloads Overrides Function ToString() As String
            Return _username + ": " + _text
        End Function
    End Class
End Namespace
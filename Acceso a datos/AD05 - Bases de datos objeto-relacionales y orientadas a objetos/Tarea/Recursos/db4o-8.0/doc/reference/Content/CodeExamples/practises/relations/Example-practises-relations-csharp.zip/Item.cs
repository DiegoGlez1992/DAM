﻿namespace Db4oDoc.Code.Practises.Relations
{
    
    class Item
    {
         
    }
}
using System;

namespace Db4objects.Db4odoc.Web.Data
{
    public class Message
    {
        string _text;
        string _username;

        public Message(string username, string text)
        {
            _username = username;
            _text = text;
        }

        public string Text
        {
            get
            {
                return _text;
            }
            set
            {
                _text = value;
            }
        }
        public override string ToString()
        {
            return _username + ": " + _text;
        }
    }
}
﻿' Copyright (C) 2004 - 2009  Versant Corporation http://www.versant.com 


Imports Db4objects.Db4o.Internal.Caching
Imports Db4objects.Db4o.IO

Namespace Db4odoc.Storage
    Class FullLRUCachingStorage
        Inherits CachingStorage
        Private _pageCount As Integer = 64

        Public Sub New(ByVal storage As IStorage)
            MyBase.New(storage)

        End Sub

        Public Sub New(ByVal storage As IStorage, ByVal pageCount As Integer, ByVal pageSize As Integer)
            MyBase.New(storage, pageCount, pageSize)
            _pageCount = pageCount
        End Sub


        Protected Overloads Overrides Function NewCache() As ICache4
            ' for a simple LRU algorythm use CacheFactory.NewLRUCache(_pageCount);
            Return CacheFactory.New2QXCache(_pageCount)
        End Function
    End Class
End Namespace

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prog02_ejerc4;

/**
 *
 * @author 
 */
public class PROG02_Ejerc4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int edad=16;
        
        //En ausencia de if, hay que utilizar el operador ternario de comparación.
        System.out.println((edad>18?"Es mayor de edad":"No es mayor de edad"));
    }
    
}

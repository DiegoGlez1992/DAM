/* Crear base de datos concesionario */
CREATE DATABASE concesionario;

/* Usar base de datos concesionario */
USE Concesionario;

/* Crear tabla propietarios */
CREATE TABLE propietarios(
id_prop INT(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,
nombre_prop VARCHAR(100) NOT NULL,
dni_prop VARCHAR(9) NOT NULL UNIQUE	/* NO se permiten duplicados */
)COMMENT='Tabla con propietarios de vehículos'
ENGINE=INNODB;

/* Crear tabla vehiculos */
CREATE TABLE vehiculos(
mat_veh CHAR(7) NOT NULL PRIMARY KEY,
marca_veh VARCHAR(50) NOT NULL,
kms_veh INT(11) NOT NULL,
precio_veh FLOAT(12) NOT NULL,
desc_veh VARCHAR(300) NOT NULL,
id_prop INT(11) NOT NULL,
FOREIGN KEY (id_prop) REFERENCES propietarios(id_prop) ON DELETE CASCADE ON UPDATE CASCADE
)COMMENT='Tabla que contiene vehículos'
ENGINE=INNODB;

/* Insertar valores en la tabla propietarios */
INSERT INTO propietarios VALUES(1, 'Diego Gonzalez Garcia', '12345678A');
INSERT INTO propietarios VALUES(2, 'Virginia Perez Vila', '12345678B');

/* Insertar valores en la tabla vehiculos */
INSERT INTO vehiculos VALUES('1234KFJ', 'Seat', 110000, 18700.00, 'Seat Leon MK3 Blanco', 1);
INSERT INTO vehiculos VALUES('1234FMK', 'Seat', 300000, 9700.00, 'Seat Leon MK1 Negro', 1);
INSERT INTO vehiculos VALUES('1234ABC', 'Citroen', 700000, 1000.00, 'Citroen Berlingo Gris', 2);

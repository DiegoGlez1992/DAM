/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.prog11.bbdd;

import java.sql.*;
import java.util.ArrayList;

/**
 * Clase que gestiona los datos de la tabla propietarios de la bbdd
 * 
 * @author nuria
 */
public class PropietariosDAO {
    
    /**
    * Método para insertar en la tabla un nuevo registro
    * 
    * @param nombre
    * @param dni
    * @param conexion
    * @return int exito para comprobar si se ha guardado con éxito el registro
    */
   public static int nuevoPropietario(String nombre,String dni,Connection conexion){

       int exito=0;

       try{
           if(!(conexion==null)){
               PreparedStatement ps=conexion.prepareStatement("INSERT INTO PROPIETARIOS"+
                    "(NOMBRE_PROP,DNI_PROP) VALUES(?,?)");
               ps.setString(1,nombre);
               ps.setString(2,dni);
               exito=ps.executeUpdate();
           }
       }
       catch(SQLException e){
           System.out.println(e);
       }
       //Se resta 1 porque si se ha insertado, executeUpdate devuelve 1.
       //(Requisito de la tarea)
       exito-=1;

       return exito;
   }        

   /**
    * Método para mostrar los vehículos de un propietario
    * 
    * @param dni
    * @param conexion
    * @return ArrayList con los datos
    */
   public static ArrayList<String> muestraVehiculos(String dni,Connection conexion){

       ArrayList<String> datos=new ArrayList<String>();

       try{
           if(!(conexion==null)){
               PreparedStatement ps=conexion.prepareStatement("SELECT MAT_VEH,MARCA_VEH,KMS_VEH,PRECIO_VEH"+
                    "FROM VEHICULOS WHERE ID_PROP = (SELECT ID_PROP FROM PROPIETARIOS WHERE DNI_PROP=?)");
               ps.setString(1,dni);
               ResultSet rs=ps.executeQuery();

               while(rs.next()){
                   int i=0;

                   datos.set(i, ("MATRICULA: "+rs.getString("mat_veh")+" -- MARCA: "+rs.getString("marca_veh")+
                        " -- KILOMETROS: "+rs.getInt("kms_veh")+" -- PRECIO: "+rs.getFloat("precio_veh")+"\n"));
                   i++;
               }
           }
       }
       catch(SQLException e){
           System.out.println(e);
       }

       return datos;
   }

   public static int eliminaPropietario(String dni,Connection conexion){

       int registros=0;

       try{
           if(!(conexion==null)){
               PreparedStatement ps=conexion.prepareStatement("DELETE * FROM PROPIETARIOS"+
                    "WHERE DNI_PROP=?");
               ps.setString(1,dni);
               registros=ps.executeUpdate();
           }
       }
       catch(SQLException e){
           System.out.println(e);
       }

       return registros;
   }
   
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.prog11.princ;

import com.prog11.bbdd.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author nuria
 */
public class Prog11_Principal {

    static ConnectionDB con=new ConnectionDB();
        
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Connection conexion=creaConexion();
        
        Scanner reader=new Scanner(System.in);
        
        int exito=0;
        
        //INSERTAR VEHÍCULOS Y PROPIETARIOS
        System.out.println("SE INSERTAN PROPIETARIOS:");
        
        exito=PropietariosDAO.nuevoPropietario("NURIA PINA CASTRO","12345678A",conexion);
        if(exito==0)
            System.out.println("Se ha guardado el propietario con éxito");
        else
            System.out.println("No se ha podido guardar el propietario");
        exito=PropietariosDAO.nuevoPropietario("JUAN PEREZ GARCIA","98765432B",conexion);
        if(exito==0)
            System.out.println("Se ha guardado el propietario con éxito");
        else
            System.out.println("No se ha podido guardar el propietario");
        exito=PropietariosDAO.nuevoPropietario("MARIA GOMEZ RUIZ","32165498C",conexion);
        if(exito==0)
            System.out.println("Se ha guardado el propietario con éxito");
        else
            System.out.println("No se ha podido guardar el propietario");
        exito=PropietariosDAO.nuevoPropietario("JOSE ORTIZ RUIZ","85263147D",conexion);
        if(exito==0)
            System.out.println("Se ha guardado el propietario con éxito");
        else
            System.out.println("No se ha podido guardar el propietario");
        
        exito=PropietariosDAO.nuevoPropietario("JUAN SAINZ ROBLES","23654123E",conexion);
        if(exito==0)
            System.out.println("Se ha guardado el propietario con éxito");
        else
            System.out.println("No se ha podido guardar el propietario");
        
        System.out.println("Pulsa Intro para continuar...");
        reader.nextLine();
        
        System.out.println("SE INSERTAN VEHÍCULOS:");
        
        exito=VehiculosDAO.nuevoVehiculo("1111AAA","PEUGEOT",1000,10000,"DESCRIPCION VEHICULO 1","12345678A",conexion);
        switch(exito){
            case 0:
                System.out.println("Se ha guardado el vehículo con éxito");
                break;
            case 1:
                System.out.println("No se ha podido guardar el vehículo porque el DNI no pertenece a ningún propietario");
                break;
            case -1:
                System.out.println("No se ha podido guardar el vehículo");
                break;
        }
        exito=VehiculosDAO.nuevoVehiculo("2222BBB","PEUGEOT",2000,20000,"DESCRIPCION VEHICULO 2","12345678A",conexion);
        switch(exito){
            case 0:
                System.out.println("Se ha guardado el vehículo con éxito");
                break;
            case 1:
                System.out.println("No se ha podido guardar el vehículo porque el DNI no pertenece a ningún propietario");
                break;
            case -1:
                System.out.println("No se ha podido guardar el vehículo");
                break;
        }
        exito=VehiculosDAO.nuevoVehiculo("3333CCC","PEUGEOT",3000,30000,"DESCRIPCION VEHICULO 3","98765432B",conexion);
        switch(exito){
            case 0:
                System.out.println("Se ha guardado el vehículo con éxito");
                break;
            case 1:
                System.out.println("No se ha podido guardar el vehículo porque el DNI no pertenece a ningún propietario");
                break;
            case -1:
                System.out.println("No se ha podido guardar el vehículo");
                break;
        }
        exito=VehiculosDAO.nuevoVehiculo("4444DDD","OPEL",4000,40000,"DESCRIPCION VEHICULO 4","98765432B",conexion);
        switch(exito){
            case 0:
                System.out.println("Se ha guardado el vehículo con éxito");
                break;
            case 1:
                System.out.println("No se ha podido guardar el vehículo porque el DNI no pertenece a ningún propietario");
                break;
            case -1:
                System.out.println("No se ha podido guardar el vehículo");
                break;
        }
        exito=VehiculosDAO.nuevoVehiculo("5555EEE","BMW",5000,50000,"DESCRIPCION VEHICULO 5","32165498C",conexion);
        switch(exito){
            case 0:
                System.out.println("Se ha guardado el vehículo con éxito");
                break;
            case 1:
                System.out.println("No se ha podido guardar el vehículo porque el DNI no pertenece a ningún propietario");
                break;
            case -1:
                System.out.println("No se ha podido guardar el vehículo");
                break;
        }
        exito=VehiculosDAO.nuevoVehiculo("6666FFF","BMW",6000,60000,"DESCRIPCION VEHICULO 6","85263147D",conexion);
        switch(exito){
            case 0:
                System.out.println("Se ha guardado el vehículo con éxito");
                break;
            case 1:
                System.out.println("No se ha podido guardar el vehículo porque el DNI no pertenece a ningún propietario");
                break;
            case -1:
                System.out.println("No se ha podido guardar el vehículo");
                break;
        }
        exito=VehiculosDAO.nuevoVehiculo("7777GGG","RENAULT",7000,70000,"DESCRIPCION VEHICULO 7","85263147D",conexion);
        switch(exito){
            case 0:
                System.out.println("Se ha guardado el vehículo con éxito");
                break;
            case 1:
                System.out.println("No se ha podido guardar el vehículo porque el DNI no pertenece a ningún propietario");
                break;
            case -1:
                System.out.println("No se ha podido guardar el vehículo");
                break;
        }
        
        System.out.println("Pulsa Intro para continuar...");
        reader.nextLine();
        
        //LISTAR TODOS LOS VEHÍCULOS
        System.out.println("LISTAR TODOS LOS VEHICULOS:");
        
        ArrayList<String> datos=VehiculosDAO.muestraVehiculoPropietario(conexion);
        for(String datoVehiculo:datos)
            System.out.println(datoVehiculo);
        
        System.out.println("Pulsa Intro para continuar...");
        reader.nextLine();
        
        //ACTUALIZAR PROPIETARIO DE UN VEHÍCULO
        System.out.println("ACTUALIZAR UN PROPIETARIO DE UN VEHICULO:");
        
        exito=VehiculosDAO.actualizaPropietario("7777GGG",1,conexion);
        if(exito==0)
            System.out.println("Se ha modificado el propietario con éxito");
        else
            System.out.println("No se ha podido modificar el propietario");
        
        exito=VehiculosDAO.actualizaPropietario("1111GGG",1,conexion);
        if(exito==0)
            System.out.println("Se ha modificado el propietario con éxito");
        else
            System.out.println("No se ha podido modificar el propietario");
        
        System.out.println("Pulsa Intro para continuar...");
        reader.nextLine();
        
        //LISTAR TODOS LOS VEHÍCULOS
        System.out.println("LISTAR TODOS LOS VEHICULOS:");
        
        datos=VehiculosDAO.muestraVehiculoPropietario(conexion);
        for(String datoVehiculo:datos)
            System.out.println(datoVehiculo);
        
        System.out.println("Pulsa Intro para continuar...");
        reader.nextLine();
        
        //ELIMINAR UN VEHÍCULO QUE EXISTA
        System.out.println("ELIMINAR UN VEHICULO QUE EXISTA:");
        
        exito=VehiculosDAO.eliminaVehiculo("4444DDD",conexion);
        if(exito==0)
            System.out.println("Se ha eliminado el vehículo con éxito");
        else
            System.out.println("No se ha podido eliminar el vehículo");
        
        System.out.println("Pulsa Intro para continuar...");
        reader.nextLine();
        
        //ELIMINAR UN VEHÍCULO QUE NO EXISTA
        System.out.println("ELIMINAR UN VEHICULO QUE NO EXISTA:");
        
        exito=VehiculosDAO.eliminaVehiculo("1111GGG",conexion);
        if(exito==0)
            System.out.println("Se ha eliminado el vehículo con éxito");
        else
            System.out.println("No se ha podido eliminar el vehículo");
        
        System.out.println("Pulsa Intro para continuar...");
        reader.nextLine();
        
        //LISTAR TODOS LOS VEHÍCULOS
        System.out.println("LISTAR TODOS LOS VEHICULOS:");
        
        datos=VehiculosDAO.muestraVehiculoPropietario(conexion);
        for(String datoVehiculo:datos)
            System.out.println(datoVehiculo);
        
        System.out.println("Pulsa Intro para continuar...");
        reader.nextLine();
        
        //LISTAR LOS VEHÍCULOS DE UNA MARCA
        System.out.println("LISTAR LOS VEHICULOS DE UNA MARCA:");
        
        datos=VehiculosDAO.muestraVehiculoMarca("PEUGEOT",conexion);
        for(String datoVehiculo:datos)
            System.out.println(datoVehiculo);
        
        System.out.println("Pulsa Intro para continuar...");
        reader.nextLine();
        
        //LISTAR TODOS LOS VEHÍCULOS DE UN PROPIETARIO
        System.out.println("LISTAR TODOS LOS VEHICULOS DE UN PROPIETARIO:");
        
        datos=PropietariosDAO.muestraVehiculos("98765432B",conexion);
        for(String datoVehiculo:datos)
            System.out.println(datoVehiculo);
        
        System.out.println("Pulsa Intro para continuar...");
        reader.nextLine();
        
        //ELIMINAR UN PROPIETARIO CON VEHÍCULOS
        System.out.println("ELIMINAR UN PROPIETARIO CON VEHICULOS:");
        
        exito=PropietariosDAO.eliminaPropietario("12345678A",conexion);
        if(exito==0)
            System.out.println("No se ha podido eliminar el propietario");
        else    
            System.out.println("Se han eliminado "+exito+" propietarios");
        
        System.out.println("Pulsa Intro para continuar...");
        reader.nextLine();
        
        //ELIMINAR UN PROPIETARIO SIN VEHÍCULOS
        System.out.println("ELIMINAR UN PROPIETARIO SIN VEHICULOS:");
        
        exito=PropietariosDAO.eliminaPropietario("23654123E",conexion);
        if(exito==0)
            System.out.println("No se ha podido eliminar el propietario");
        else    
            System.out.println("Se han eliminado "+exito+" propietarios");
        
        System.out.println("Gracias por usar el programa!!!");
        
        cierraConexion(conexion);
    }
    
    /**
     * Método para crear la conexión con la bbdd
     * 
     * @return conexion
     */
    private static Connection creaConexion(){
        
        Connection conexion=ConnectionDB.openConnection();
        
        return conexion;
    }
    
    /**
     * Método para cerrar la coneción con la bbdd
     * 
     * @param conexion 
     */
    private static void cierraConexion(Connection conexion){
        ConnectionDB.closeConnection(conexion);
    }
    
}

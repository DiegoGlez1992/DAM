/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.prog11.bbdd;
import java.sql.*;
import java.util.ArrayList;

/**
 * Clase que gestiona los datos de la tabla vehiculos de la bbdd
 * 
 * @author nuria
 */
public class VehiculosDAO {
    
    /**
     * Método para insertar en la tabla un nuevo registro
     * 
     * @param matricula
     * @param marca
     * @param kms
     * @param precio
     * @param descripcion
     * @param dni
     * @param conexion
     * @return int exito para comprobar si se ha guardado con éxito el registro
     *      (1 -> Si el propietario no existe 0 -> Se inserta el vehiculo -1 -> No se inserta el vehiculo
     */
    public static int nuevoVehiculo(String matricula,String marca,int kms,float precio,String descripcion,String dni,Connection conexion){
       
        int exito=0;

        try{
            if(!(conexion==null)){
                PreparedStatement ps=conexion.prepareStatement("SELECT ID_PROP FROM propietarios"+
                    "WHERE DNI_PROP=?");
                ps.setString(1,dni);
                ResultSet rs=ps.executeQuery();
                
                if(!(rs==null)){//Si existe un propietario con ese DNI
                    int id_prop=rs.getInt(1);

                    ps=conexion.prepareStatement("INSERT INTO VEHICULOS"+
                        "(MAT_VEH,MARCA_VEH,KMS_VEH,PRECIO_VEH,DESC_VEH,ID_PROP) VALUES(?,?,?,?,?,?)");
                    ps.setString(1,matricula);
                    ps.setString(2,marca);
                    ps.setInt(3,kms);
                    ps.setFloat(4,precio);
                    ps.setString(5,descripcion);
                    ps.setInt(6,id_prop);
                    exito=ps.executeUpdate();
                }
                else{//No existe un propietario con ese DNI
                    exito=2;
                }
            }
        }
        catch(SQLException e){
            System.out.println(e);
        }
        //Se resta 1 porque si se ha insertado, executeUpdate devuelve 1.
        //(Requisito de la tarea)
        exito-=1;

        return exito;
    }
    
    /**
     * Método para modificar el propietario de un vehículo
     * 
     * @param matricula
     * @param id_prop
     * @param conexion
     * @return int exito para comprobar si se ha modificado con éxito el registro
     */
    public static int actualizaPropietario(String matricula,int id_prop,Connection conexion){
        
        int exito=0;
        
        try{
            if(!(conexion==null)){
                PreparedStatement ps=conexion.prepareStatement("UPDATE VEHICULOS SET ID_PROP=?"+
                    "WHERE MAT_VEH=?");
                ps.setInt(1,id_prop);
                ps.setString(2,matricula);
                exito=ps.executeUpdate();
                if(exito>0)
                    exito=1;
            }
        }
        catch(SQLException e){
            System.out.println(e);
        }
       
        //Se resta 1 porque si se ha modificado, executeUpdate devuelve al menos 1.
        //(Requisito de la tarea)
        exito-=1;
        return exito;
    }
    
    /**
     * Método para eliminar un vehículo
     * 
     * @param matricula
     * @param conexion
     * @return int exito para comprobar si se ha eliminado con éxito el registro
     */
    public static int eliminaVehiculo(String matricula,Connection conexion){

        int exito=0;

        try{
            if(!(conexion==null)){
                PreparedStatement ps=conexion.prepareStatement("DELETE FROM VEHICULOS"+
                        "WHERE MAT_VEH=?");
                ps.setString(1,matricula);
                exito=ps.executeUpdate();
            }
        }
        catch(SQLException e){
            System.out.println(e);
        }

        //Se resta 1 porque si se ha eliminado, executeUpdate devuelve 1.
        //(Requisito de la tarea)
        exito-=1;
        return exito;
    }
    
    /**
     * Método para mostrar una lista con todos los vehículos indicando el nombre 
     * del propietario
     * 
     * @param conexion
     * @return ArrayList con los datos
     */
    public static ArrayList<String> muestraVehiculoPropietario (Connection conexion){
        
        ArrayList<String> datos=new ArrayList<String>();

        try{
            if(!(conexion==null)){
                PreparedStatement ps=conexion.prepareStatement("SELECT MAT_VEH,MARCA_VEH,KMS_VEH,PRECIO_VEH,DESC_VEH,NOMBRE_PROP "+
                        "FROM VEHICULOS V INNER JOIN PROPIETARIOS P ON V.ID_PROP=P.ID_PROP");
                ResultSet rs=ps.executeQuery();

                while(rs.next()){
                    int i=0;

                    datos.add(i, ("MATRICULA: "+rs.getString("mat_veh")+" -- MARCA: "+rs.getString("marca_veh")+
                        " -- KILOMETROS: "+rs.getInt("kms_veh")+" -- PRECIO: "+rs.getFloat("precio_veh")+
                        " -- DESCRIPCIÓN: "+rs.getString("desc_veh")+" -- PROPIETARIO: ")+rs.getString("nombre_prop")+"\n");
                    i++;
                }
            }
        }
        catch(SQLException e){
            System.out.println(e);
        }

        return datos;
    }
    
    /**
     * Método para mostrar los vehículos guardados (con datos seleccionados)
     * 
     * @param conexion
     * @return ArrayList con los datos
     */
    public static ArrayList<String> muestraVehiculo (Connection conexion){
        
        ArrayList<String> datos=new ArrayList<String>();

        try{
            if(!(conexion==null)){
                PreparedStatement ps=conexion.prepareStatement("SELECT MAT_VEH,MARCA_VEH,KMS_VEH,PRECIO_VEH,"+
                    "FROM VEHICULOS");
                ResultSet rs=ps.executeQuery();

                while(rs.next()){
                    int i=0;

                    datos.set(i, ("MATRICULA: "+rs.getString("mat_veh")+" -- MARCA: "+rs.getString("marca_veh")+
                        " -- KILOMETROS: "+rs.getInt("kms_veh")+" -- PRECIO: "+rs.getFloat("precio_veh")+"\n"));
                    i++;
                }
            }
        }
        catch(SQLException e){
            System.out.println(e);
        }

        return datos;
    }
    
    /**
     * Método para mostrar los datos de los vehículos de una marca (con nombre
     * del propietario)
     * 
     * @param marca
     * @param conexion
     * @return 
     */
    public static ArrayList<String> muestraVehiculoMarca (String marca, Connection conexion){
        
        ArrayList<String> datos=new ArrayList<String>();

        try{
            if(!(conexion==null)){
                PreparedStatement ps=conexion.prepareStatement("SELECT MAT_VEH,MARCA_VEH,KMS_VEH,PRECIO_VEH,DESC_VEH,NOMBRE_PROP"+
                    "FROM VEHICULOS V INNER JOIN PROPIETARIOS P ON V.ID_PROP=P.ID_PROP WHERE MARCA_VEH=?");
                ps.setString(1,marca);
                ResultSet rs=ps.executeQuery();

                while(rs.next()){
                    int i=0;

                    datos.set(i, ("MATRICULA: "+rs.getString("mat_veh")+" -- MARCA: "+rs.getString("marca_veh")+
                        " -- KILOMETROS: "+rs.getInt("kms_veh")+" -- PRECIO: "+rs.getFloat("precio_veh")+
                        " -- DESCRIPCIÓN: "+rs.getString("desc_veh")+" -- PROPIETARIO: ")+rs.getString("nombre_prop")+"\n");
                    i++;
                }
            }
        }
        catch(SQLException e){
            System.out.println(e);
        }

        return datos;
    } 
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.prog11.bbdd;

import java.sql.*;

/**
 * Clase para la gestión de la conexión con la bd
 * 
 * @author nuria
 */
public class ConnectionDB {
    
    /**
     * Los datos necesarios para la conexión con la bbdd se indican como constantes
     * para facilitar su modificación en caso necesario
     */
    private static final String DRIVER="org.mariadb.jdbc.Driver";
    private static final String BBDD="jdbc:mariadb://localhost:3306/concesionario";
    private static final String USER="root";
    private static final String PASS="root";
       
    /**
     * Método que establece la conexión con la bbdd
     * 
     * @return conexion (Connection)
     */
    public static Connection openConnection(){
        
        Connection conexion=null;
        
        try{
            Class.forName(DRIVER);
            conexion=(Connection)DriverManager.getConnection(BBDD,USER,PASS);
        }
        catch(SQLException | ClassNotFoundException e){
            System.out.println(e);
        }
        return conexion;
    }
    
    /**
     * Método que finaliza la conexión con la bbdd que se le pasa como parámetro
     * 
     * @param conexion 
     */
    public static void closeConnection(Connection conexion){
        
        try{
            conexion.close();
        }
        catch(SQLException e){
            System.out.println(e);
        }
    }
   
}

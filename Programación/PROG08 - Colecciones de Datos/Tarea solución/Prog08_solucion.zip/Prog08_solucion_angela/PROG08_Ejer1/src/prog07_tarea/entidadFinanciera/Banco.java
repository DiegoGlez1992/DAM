package prog07_tarea.entidadFinanciera;

import java.util.LinkedList;
import java.util.Scanner;

/**
 * Esta clase tiene como fin almacenar en un array de objetos los objetos de todos
 * los tipos de cuenta que podemos generar gracias a las clases CuentaBancaria, 
 * CuentaAhorros, CuentaCorriente, y sus subclases Cuenta Corriente Personal y 
 * Cuenta Corriente Empresa. Además, contiene los métodos que permiten operar 
 * con las diferentes cuentas.

 */
public class Banco {
/* Utilizar una estructura dinámica. Justificar respuesta.
   Añadir opción eliminar cuenta bancaria. Eliminar si existe y saldo igual a 0.   
*/
/**
 * Uso del interfaz LinkedList para almacenar objetos. He escogido este tipo de
 * estructura porque permite más operaciones que la interfaz Set, y dentro de List
 * como tenemos pensado que haya operaciones de eliminación frecuentes, es más 
 * adecuada que ArrayList.
 */
    LinkedList<CuentaBancaria> banco= new LinkedList<CuentaBancaria>();
/**
 * Reformulación del método que añade objetos al la lista.
 * @param nuevaCuenta Objeto de la clase CuentaBancaria.
 * @return Devuelve true si el método añade el objeto correctamente, o false en
 * caso contrario.
 */    
    public boolean abrirCuenta (CuentaBancaria nuevaCuenta){
        return banco.add(nuevaCuenta);
    }
/**
 * Reformulación del método que imprime por pantalla los datos de cada objeto
 * almacenado enla lista.
 */    
    public void listadoCuentas(){
        for(CuentaBancaria nC: banco){
            System.out.println(nC.devolverInfoString());
        }
    }
/**
 * Método que solicita por teclado el número IBAN para localizar una cuenta bancaria.
 * @return Devuelve la cadena de caracteres solicitada por teclado.
 * No es necesario reformular este método para el uso de estructuras dinámicas.
 */    
    public String solicitarIBAN(){
        System.out.println("Por favor, ingrese el número IBAN, recuerde que el "
                + "\nformato de este número consta de las letras ES en mayúsculas y "
                + "\n20 dígitos numéricos a continuación sin espacios.");
        Scanner teclado= new Scanner(System.in);
        String numIBAN= teclado.next();
        return numIBAN;
    }
/**
 * Reformulación del método que imprime por pantalla los datos de una cuenta bancaria
 * localizada por su variable IBAN.
 * @param iban Parámetro para localizar el objeto cuenta concreto.
 * @return Si se cumple la condición devuelve una cadena de caracteres con la 
 * información de la cuenta, si no devuelve null.
 */    
    public String informaciónCuenta (String iban){
        String infoCuenta;
        for(CuentaBancaria nC: banco){
            if(nC.getNumIBAN().equals(iban)){
                infoCuenta= nC.devolverInfoString();
                return infoCuenta;
            }
        }
        return null;
    }
/**
 * Método que pide por teclado un double que representa una cantidad de dinero
 * a ingresar o retirar en cuenta.
 * @return Devuelve el valor de dicha cantidad.
 * Si el usuario introduce un tipo de dato no válido, se lanza una excepción.
 * No es necesario reformular este método para el uso de estructuras dinámicas.
 */    
    public double solicitarImporte(){
        try{
            System.out.println("Por favor, indique la cantidad con la que operar. "
                    + "\n Recuerde que dicha cantidad no admite letras ni símbolos.");
            Scanner teclado= new Scanner(System.in);
            double cantImporte= teclado.nextDouble();
            return cantImporte;
        }catch(java.util.InputMismatchException ex){
            throw new IllegalArgumentException("Cantidad mal introducida, revíselo.");
        }
    }
/**
 * Reformulación del método que solicita un importe por teclado y lo suma al valor
 * almacenado en la variable saldo de un objeto en la lista, que se localiza por
 * el valor de la variable IBAN.
 * @param iban Valor del IBAN para poder encontrar la cuenta.
 * @param ingreso Valor de la cantidad a ingresar.
 * @return exitoOPeracion Variable que informa del éxito de la operación.
 */    
    public boolean ingresoCuenta(String iban, double ingreso){
        boolean exitoOperacion= false;
        
        for (CuentaBancaria nC: banco){
            if(nC.getNumIBAN().equals(iban) && ingreso>0){
                double nuevoSaldo= nC.saldo + ingreso;
                nC.setSaldo(nuevoSaldo);
                exitoOperacion= true;
            }
        }
        return exitoOperacion;
    }
/**
 * Reformulación del método que solicita un importe por teclado y lo resta al valor
 * almacenado en la variable saldo de un objeto en la lista, que se localiza por
 * el valor de la variable IBAN.
 * @param iban Valor del IBAN para poder encontrar la cuenta.
 * @param retirada Valor de la cantidad a ingresar.
 * @return exitoOPeracion Variable que informa del éxito de la operación.
 */    
    public boolean retiradaCuenta(String iban, double retirada){
        boolean exitoOperacion= false;
        
        for (CuentaBancaria nC: banco){
            if(nC.getNumIBAN().equals(iban) && retirada<= nC.saldo){
                double nuevoSaldo= nC.saldo - retirada;
                nC.setSaldo(nuevoSaldo);
                exitoOperacion= true;
            }
        }
        return exitoOperacion;
    }
/**
 * Reformulación del método que solicita un IBAN por teclado e imprime por pantalla
 * los datos de la variable saldo de la cuenta que coincida con dicho IBAN.
 * @param iban Parámetro que recibe el método para encontrar la cuenta deseada.
 */    
    public void mostrarSaldo(String iban){
        for (CuentaBancaria nC: banco){
            if(nC.getNumIBAN().equals(iban)){
                System.out.println("En la cuenta " + nC.numIBAN + " el saldo actual es " + nC.saldo + " €.");
            }
        }
    }
/**
 * Método que elimina una cuenta determinada por el valor del IBAN que entra por
 * parámetro, tras solicitarlo por teclado.
 * @param iban Valor IBAN que debe coincidir con el de alguno de los objetos 
 * de tipo cuenta bancaria almacenados.
 */    
    /*public void eliminarCuenta(String iban){
        try{
            for (CuentaBancaria nC: banco){
                if(nC.numIBAN.equals(iban) && nC.saldo == 0){
                    banco.remove(nC);
                    System.out.println("Cuenta eliminada con éxito.");
                }
            }
        }catch(java.util.InputMismatchException ex){
            throw new IllegalArgumentException("No se pudo eliminar la cuenta.");
        }  
    }*/
    
    public void eliminarCuenta(String iban){
     
        for (CuentaBancaria nC: banco){
            if(nC.numIBAN.equals(iban) && nC.saldo == 0){
                banco.remove(nC);
                System.out.println("Cuenta eliminada con éxito.");
                return;
            }       
        }
        System.out.println("No se pudo eliminar la cuenta.");
    }
}

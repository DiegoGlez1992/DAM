package prog07_tarea.entidadFinanciera;

import java.util.Scanner;
import prog07_tarea.utilidades.Persona;

/**
 * Subclase de la clase CuentaCorriente que añade a sus propiedades una comisión
 * de mantenimiento de la cuenta.

 */
public class CCPersonal extends CuentaCorriente {
    //Atributo de la clase.
    double comisionM;
/**
 * Método constructor para la creación de objetos de tipo CCPersonal (Cuenta 
 * Corriente Personal).
 * @param titular
 * @param saldo
 * @param numIBAN
 * @param entdAutorizada
 * @param comisionM 
 */    
    public CCPersonal (Persona titular, double saldo, String numIBAN, 
            String entdAutorizada, double comisionM){
        super(titular, saldo, numIBAN, entdAutorizada);
        this.comisionM= comisionM;
    }
/**
 * Implementación del método alojado en la interfaz Imprimible que recoge en una
 * cadena de caracteres los datos de los atributos de este tipo de cuenta.
 * @return Devuelve una cadena de caracteres.
 */
    @Override
    public String devolverInfoString(){
        String infoCuenta;
        
        infoCuenta= "Titular: "+  this.titular.nombre + " " + this.titular.apellidos + " " 
                + this.titular.dni + " -- Saldo: "+ this.saldo + " -- IBAN: "
                + this.numIBAN + " -- Entidad Autorizada: " + this.entdAutorizada 
                + " -- Comisión: " + this.comisionM;
        
        return infoCuenta;
    }
/**
 * Método que pide por teclado datos que nos servirán para dar valor a los atributos
 * de un objeto de la clase.
 * Se capturan excepciones por posibles errores en el tipo de dato introducido por teclado.
 * Se utiliza el método validarIBAN de la clase CuentaBancaria, antes de la creación de objetos.
 * Se instancia un objeto Persona, que es atributo de la clase.
 * Se instancia el propio objeto de la clase y se pasan por parámetro los valores recogidos.
 * @return Devuelve un objeto con los valores de sus atributos.
 * En el caso de no ser validado se lanza una excepción controlada que contiene una cadena
 * de caracteres.
 */    
    public static CCPersonal pedirDatosObjeto() throws IllegalArgumentException{
        double saldoT;
        double comisT;
        Scanner teclado= new Scanner(System.in);
        System.out.println("Ha escogido Cuenta de Corriente Personal."
                + "\n Rellene los siguientes datos:");
        System.out.println("Nombre del titular: ");
        String nombreT= teclado.next();
        System.out.println("Apellidos del titular: ");
        String apellT= teclado.next();
        System.out.println("DNI del titular: ");
        String dniT= teclado.next();
        try{
            System.out.println("Saldo inicial en la cuenta: ");
            saldoT= teclado.nextDouble();
        }catch(java.util.InputMismatchException ex){
            throw new IllegalArgumentException("Saldo mal introducido, revísalo.");
        }
        System.out.println("IBAN de la cuenta: ");
        String ibanT= teclado.next();
        System.out.println("Entidades autorizadas a hacer cobros en la cuenta: ");
        String entT= teclado.next();
        try{
            System.out.println("Comisión de mantenimiento de la cuenta: ");
            comisT= teclado.nextDouble();
        }catch(java.util.InputMismatchException ex){
            throw new IllegalArgumentException("Comisión mal introducida, revísalo.");
        }
        
        boolean validoParaCrear= CuentaAhorros.validarIBAN(ibanT);
        if(validoParaCrear== true){
            Persona pers= new Persona(nombreT, apellT, dniT);
            CCPersonal nuevCuen= new CCPersonal(pers, saldoT, ibanT, entT, comisT);
            
            return nuevCuen;
        }else{
            throw new IllegalArgumentException("IBAN introducido de forma incorrecta, vuelva a intentarlo");
        } 
    }
}

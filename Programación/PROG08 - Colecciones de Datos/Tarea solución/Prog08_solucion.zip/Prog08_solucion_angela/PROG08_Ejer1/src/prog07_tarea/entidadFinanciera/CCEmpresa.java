package prog07_tarea.entidadFinanciera;

import java.util.Scanner;
import prog07_tarea.utilidades.Persona;

/**
 * Subclase de la clase CuentaCorriente, que añade a sus propiedades la posibilidad 
 * de tener una cantidad de descubierto, un tipo de interés por el descubierto y una 
 * comisión fija por cada descubierto. Sólo este tipo de cuenta maneja descubiertos.

 */
public class CCEmpresa extends CuentaCorriente {
    //Atributos de la clase.
    double intDescubierto;
    double maxDescubierto;
    double comisDescubierto;
/**
 * Método constructor que permite la creación de objetos de tipo CCEMpresa (Cuenta
 * Corriente de Empresa).
 * @param titular
 * @param saldo
 * @param numIBAN
 * @param entdAutorizada
 * @param intDescubierto
 * @param maxDescubierto 
 * @param comiDescubierto 
 */    
    public CCEmpresa (Persona titular, double saldo, String numIBAN, 
            String entdAutorizada, double intDescubierto, double maxDescubierto,
            double comiDescubierto){
        super(titular, saldo, numIBAN, entdAutorizada);
        this.intDescubierto= intDescubierto;
        this.maxDescubierto= maxDescubierto;
        this.comisDescubierto= comiDescubierto;
    }
/**
 * Implementación del método alojado en la interfaz Imprimible que recoge en una
 * cadena de caracteres los datos de los atributos de este tipo de cuenta.
 * @return Devuelve una cadena de caracteres.
 */
    @Override
    public String devolverInfoString(){
        String infoCuenta;
        
        infoCuenta= "Titular: "+  this.titular.nombre + " " + this.titular.apellidos + " " 
                + this.titular.dni  + " -- Saldo: "+ this.saldo + " -- IBAN: "
                + this.numIBAN + " -- Entidad Autorizada: " + this.entdAutorizada 
                + " -- Interés por Descubierto: " + this.intDescubierto + " -- Máximo Descubierto Permitido: "
                + this.maxDescubierto;
        
        return infoCuenta;
    }
/**
 * Método que pide por teclado datos que nos servirán para dar valor a los atributos
 * de un objeto de la clase.
 * Se capturan excepciones por posibles errores en el tipo de dato introducido por teclado.
 * Se utiliza el método validarIBAN de la clase CuentaBancaria, antes de la creación de objetos.
 * Se instancia un objeto Persona, que es atributo de la clase.
 * Se instancia el propio objeto de la clase y se pasan por parámetro los valores recogidos.
 * @return Devuelve un objeto con los valores de sus atributos.
 * En el caso de no ser validado se lanza una excepción controlada que contiene una cadena
 * de caracteres.
 */    
    public static CCEmpresa pedirDatosObjeto() throws IllegalArgumentException{
        double saldoT;
        double maxDescT;
        double intDescT;
        double comDescT;
        Scanner teclado= new Scanner(System.in);
        System.out.println("Ha escogido Cuenta Corriente de Empresa."
                + "\n Rellene los siguientes datos:");
        System.out.println("Nombre del titular: ");
        String nombreT= teclado.next();
        System.out.println("Apellidos del titular: ");
        String apellT= teclado.next();
        System.out.println("DNI del titular: ");
        String dniT= teclado.next();
        try{
            System.out.println("Saldo inicial en la cuenta: ");
            saldoT= teclado.nextDouble();
        }catch(java.util.InputMismatchException ex){
            throw new IllegalArgumentException("Saldo mal introducido, revísalo.");
        }
        System.out.println("IBAN de la cuenta: ");
        String ibanT= teclado.next();
        System.out.println("Entidades autorizadas a hacer cobros en la cuenta: ");
        String entT= teclado.next();
        try{
            System.out.println("Interés sobre descubierto en la cuenta: ");
            intDescT= teclado.nextDouble();
        }catch(java.util.InputMismatchException ex){
            throw new IllegalArgumentException("Interés sobre descubierto mal introducido, revísalo.");
        }
        try{
            System.out.println("Máximo descubierto permitido en la cuenta: ");
            maxDescT= teclado.nextDouble();
        }catch(java.util.InputMismatchException ex){
            throw new IllegalArgumentException("Máximo descubierto mal introducido, revísalo.");
        }
        try{
            System.out.println("Comisión por descubierto permitido en la cuenta: ");
            comDescT= teclado.nextDouble();
        }catch(java.util.InputMismatchException ex){
            throw new IllegalArgumentException("Comisión por descubierto mal introducida, revísalo.");
        }
        
        boolean validoParaCrear= CuentaAhorros.validarIBAN(ibanT);
        if(validoParaCrear== true){
            Persona pers= new Persona(nombreT, apellT, dniT);
            CCEmpresa nuevCuen= new CCEmpresa(pers, saldoT, ibanT, entT, intDescT, maxDescT, comDescT);
            
            return nuevCuen;
        }else{
            throw new IllegalArgumentException("IBAN introducido de forma incorrecta, vuelva a intentarlo");
        } 
    }    
}

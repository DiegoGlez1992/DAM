package prog07_tarea.utilidades;

/**
 * Interfaz creada para tener preparado un método que imprima cadenas de caracteres
 * por pantalla.
 */
public interface Imprimible {
/**
 * Método que se ampliará en las clases que necesiten imprimir datos por pantalla.
 * @return devuelve una cadena de caracteres.
 */    
    public String devolverInfoString();
}

package prog07_tarea.entidadFinanciera;

import java.util.Scanner;
import prog07_tarea.utilidades.Persona;

/**
 * Clase hija de CuentaBancaria que añade a sus cualidades la lista de entidades
 * autorizadas al cobro de recibos domiciliados en una cuenta.

 */
public class CuentaCorriente extends CuentaBancaria {
    //Atributo de la clase.
    String entdAutorizada;
/**
 * Método constructor para la creación de objetos de tipo CuentaCorriente.
 * @param titular
 * @param saldo
 * @param numIBAN
 * @param entdAutorizada 
 */ 
    public CuentaCorriente (Persona titular, double saldo, String numIBAN, String entdAutorizada){
        super(titular, saldo, numIBAN);
        this.entdAutorizada= entdAutorizada;
    }
/**
 * Implementación del método alojado en la interfaz Imprimible que recoge en una
 * cadena de caracteres los datos de los atributos de este tipo de cuenta.
 * @return Devuelve una cadena de caracteres.
 */
    @Override
    public String devolverInfoString(){
        String infoCuenta;
        
        infoCuenta= "Titular: "+  this.titular.nombre + " " + this.titular.apellidos + " " 
                + this.titular.dni  + " -- Saldo: "+ this.saldo + " -- IBAN: "
                + this.numIBAN + " -- Entidad Autorizada: " + this.entdAutorizada;
        
        return infoCuenta;
    }
/**
 * Método que pide por teclado datos que nos servirán para dar valor a los atributos
 * de un objeto de la clase.
 * Se capturan excepciones por posibles errores en el tipo de dato introducido por teclado.
 * Se utiliza el método validarIBAN de la clase CuentaBancaria, antes de la creación de objetos.
 * Se instancia un objeto Persona, que es atributo de la clase.
 * Se instancia el propio objeto de la clase y se pasan por parámetro los valores recogidos.
 * @return Devuelve un objeto con los valores de sus atributos.
 * En el caso de no ser validado se lanza una excepción controlada que contiene una cadena
 * de caracteres.
 */    
    public static CuentaCorriente pedirDatosObjeto() throws IllegalArgumentException{
        double saldoT;
        double inteT;
        Scanner teclado= new Scanner(System.in);
        System.out.println("Ha escogido Cuenta Corriente."
                + "\n Rellene los siguientes datos:");
        System.out.println("Nombre del titular: ");
        String nombreT= teclado.next();
        System.out.println("Apellidos del titular: ");
        String apellT= teclado.next();
        System.out.println("DNI del titular: ");
        String dniT= teclado.next();
        try{
            System.out.println("Saldo inicial en la cuenta: ");
            saldoT= teclado.nextDouble();
        }catch(java.util.InputMismatchException ex){
            throw new IllegalArgumentException("Saldo mal introducido, revísalo.");
        }
        System.out.println("IBAN de la cuenta: ");
        String ibanT= teclado.next();
        System.out.println("Entidades autorizadas a hacer cobros en la cuenta: ");
        String entT= teclado.next();
        
        boolean validoParaCrear= CuentaAhorros.validarIBAN(ibanT);
        if(validoParaCrear== true){
            Persona pers= new Persona(nombreT, apellT, dniT);
            CuentaCorriente nuevCuen= new CuentaCorriente(pers, saldoT, ibanT, entT);
            
            return nuevCuen;
        }else{
            throw new IllegalArgumentException("IBAN introducido de forma incorrecta, vuelva a intentarlo");
        } 
    }    
}

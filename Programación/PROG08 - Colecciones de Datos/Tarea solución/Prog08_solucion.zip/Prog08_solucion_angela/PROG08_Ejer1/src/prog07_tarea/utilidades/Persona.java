package prog07_tarea.utilidades;

/**
 * Clase creada para generar objetos de tipo Persona que almacenen datos 
 * personales en forma de cadena de caracteres.
 */
public class Persona {
    public String nombre;
    public String apellidos;
    public String dni;
/**
 * Constructor de la clase Persona con sus atributos por parámetro.
 * @param nombre
 * @param apellidos
 * @param dni 
 */    
    public Persona(String nombre, String apellidos, String dni){
        this.nombre= nombre;
        this.apellidos= apellidos;
        this.dni= dni;
    }
}

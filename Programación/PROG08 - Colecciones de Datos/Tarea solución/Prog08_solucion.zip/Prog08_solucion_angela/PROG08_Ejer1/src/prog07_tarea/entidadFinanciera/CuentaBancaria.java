package prog07_tarea.entidadFinanciera;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import prog07_tarea.utilidades.Imprimible;
import prog07_tarea.utilidades.Persona;

/**
 * Clase tipo abstract que define cuentas bancarias genéricas. Permite que otras
 * clases más específicas hereden de ella. Es abstract porque no queremos instancias 
 * de esta clase, si no de sus clases hijas.

 */
public abstract class CuentaBancaria implements Imprimible {
/**
 * Atributos que heredarán para sus objetos las clases hijas. Los datos personales
 * se recogen en los atributos de un objeto de la clase Persona.
 */    
    Persona titular;
    double saldo;
    String numIBAN;
/**
 * Método constructor que ayudará a la creación de objetos de las clases hijas.
 * @param titular
 * @param saldo
 * @param numIBAN 
 */    
    public CuentaBancaria(Persona titular, double saldo, String numIBAN){
        this.titular= titular;
        this.saldo= saldo;
        this.numIBAN= numIBAN;
    }
/**
 * Implementación del método alojado en la interfaz Imprimible que recoge en una
 * cadena de caracteres los datos de los atributos de este tipo de cuenta.
 * @return Devuelve una cadena de caracteres.
 */
    @Override
    public String devolverInfoString(){
        String infoCuenta;
        
        infoCuenta= "Titular: "+  this.titular.nombre + " " + this.titular.apellidos + " " 
                + this.titular.dni  + " -- Saldo: "+ this.saldo + " -- IBAN: ";
        
        return infoCuenta;
    }
/**
 * Método setter para actualizar el valor de la variable saldo en los diferentes
 * objetos tipo cuenta.
 * @param saldo 
 */
    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
/**
 * Método para validar la correcta configuración del valor de la variable numIBAN
 * cuando se solicita por teclado.
 * @param nIBAN Recibe una cadena de caracteres.
 * @return Devuelve un booleano que confirma que cumple con la expresión regular
 * que sirve de patrón.
 */    
    public static boolean validarIBAN(String nIBAN){
        Pattern patronIBAN= Pattern.compile("(ES{1})([0-9]{1,20})");
        Matcher matchIBAN= patronIBAN.matcher(nIBAN);
        if(!matchIBAN.matches()){
            return false;
        }
        return true;
    }
/**
 * Método getter del string IBAN para obtener su valor.
 * @return Devuelve el valor almacenado en la variable IBAN.
 */
    public String getNumIBAN() {
        return numIBAN;
    }
}

package prog07_tarea;

import MenuOpciones.Menu;
import MenuOpciones.Opciones;
import java.util.Scanner;
import prog07_tarea.entidadFinanciera.Banco;
import prog07_tarea.entidadFinanciera.CuentaCorriente;
import prog07_tarea.entidadFinanciera.CCEmpresa;
import prog07_tarea.entidadFinanciera.CCPersonal;
import prog07_tarea.entidadFinanciera.CuentaAhorros;


/**
 * Clase que contiene el método main y que interactúa con el usuario. Esta clase
 * pide datos por teclado y devuelve datos por pantalla.
 */
public class Principal {
/**
 * Dentro del método main están los códigos y las llamadas a métodos para:
 * -Mostrar por pantalla un menú de opciones.
 * -Llevar a cabo cada una de las acciones del menú.
 * Dentro de las opciones del menú se incluyen acciones como recoger datos,
 * crear objetos, 
 * @param args the command line arguments
 */
    public static void main(String[] args) {
        //Objetos que se necesitarán para el uso de los métodos de su clase.
        Scanner teclado= new Scanner(System.in);
        Banco banco= new Banco();
/**
 * Utilizando las clases Menu y Opciones, creamos el menú que se va a mostrar 
 * al usuario.
 * Con el método mostrarMenu() se imprime por pantalla.
 * Con el método 
 */          
        Menu menuBanco= new Menu(new Opciones[]{
            new Opciones (1, "Abrir nueva cuenta."),
            new Opciones (2, "Ver listado de cuentas disponibles."),
            new Opciones (3, "Obtener datos de una cuenta."),
            new Opciones (4, "Realizar un ingreso en una cuenta."),
            new Opciones (5, "Retirar efectivo de una cuenta."),
            new Opciones (6, "Consultar el saldo actual de una cuenta."),
            new Opciones (7, "Eliminar cuenta."),
            new Opciones (8, "Salir de la aplicación.")
        });
/**
 * Bucle do{}while(); que muestra el menú por pantalla y lo vuelve a mostrar hasta
 * seleccionar la opción Salir.
 * Utiliza los métodos .mostrarMenu() y .solicitarOpcionMenu()
 * Dentro del bucle un switch(){} gestiona las opciones del menú.
 * Utiliza métodos de la clase Banco, y de la clase CuentaBancaria y sus descendientes.
 */     
        //Variable que facilita un entero al switch que gestiona las opciones de menú.           
        int opcMenu;
        do{
            menuBanco.mostrarMenu();
            opcMenu= menuBanco.solicitarOpcionMenu();
            switch(opcMenu){
                //Opción 1 abrir cuenta. Selección del tipo de cuenta, recogida de datos, instancia de objeto, guardar objeto en array.
                case 1:
                    System.out.println("Por favor, escoja el tipo de cuenta que desea "
                            + "crear, escribiendo su número identificador: "
                            + "\n Cuenta de Ahorros - 1"
                            + "\n Cuenta Corriente - 2"
                            + "\n Cuenta Corriente Personal - 3"
                            + "\n Cuenta Corriente de Empresa - 4");
                    int tipoCuenta= teclado.nextInt();
                    switch(tipoCuenta){
                        case 1:   
                            try{
                                if(banco.abrirCuenta(CuentaAhorros.pedirDatosObjeto())){
                                    System.out.println("Cuenta creada con éxito");
                                }else{
                                    System.out.println("La base de datos está completa, no es posible registrar nuevas cuentas.");
                                }
                            }catch(IllegalArgumentException ex){
                                System.out.println(ex.getMessage());        
                            }
                        break;
                        case 2:
                            try{
                                if(banco.abrirCuenta(CuentaCorriente.pedirDatosObjeto())){
                                    System.out.println("Cuenta creada con éxito");
                                }else{
                                    System.out.println("La base de datos está completa, no es posible registrar nuevas cuentas.");
                                }
                            }catch(IllegalArgumentException ex){
                                System.out.println(ex.getMessage());        
                            }
                        break;
                        case 3:
                            try{
                                if(banco.abrirCuenta(CCPersonal.pedirDatosObjeto())){
                                    System.out.println("Cuenta creada con éxito");
                                }else{
                                    System.out.println("La base de datos está completa, no es posible registrar nuevas cuentas.");
                                }
                            }catch(IllegalArgumentException ex){
                                System.out.println(ex.getMessage());        
                            }
                        break;
                        case 4:
                            try{
                                if(banco.abrirCuenta(CCEmpresa.pedirDatosObjeto())){
                                    System.out.println("Cuenta creada con éxito");
                                }else{
                                    System.out.println("La base de datos está completa, no es posible registrar nuevas cuentas.");
                                }
                            }catch(IllegalArgumentException ex){
                                System.out.println(ex.getMessage());        
                            }
                        break;
                    }    
                break;
                //Opción 2 listar objetos del array de banco.
                case 2:
                    banco.listadoCuentas();    
                break;
                //Opción 3 imprimir información de un objeto concreto, detectado por su atributo numIBAN.
                case 3:
                    String numeIBAN= banco.solicitarIBAN();
                    if(banco.informaciónCuenta(numeIBAN)== null){
                        System.out.println("No existen cuentas con el IBAN introducido. Vuelva a intentarlo.");
                    }else{
                        System.out.println(banco.informaciónCuenta(numeIBAN));
                    }
                break;
                //Opción 4 hacer un ingreso en el atributo saldo de un objeto del array.
                case 4:
                    try{
                        numeIBAN= banco.solicitarIBAN();
                        double importe= banco.solicitarImporte();
                        if(banco.ingresoCuenta(numeIBAN, importe)){
                            System.out.println("Ingreso realizado con éxito");
                        }else{
                            System.out.println("El ingreso no pudo llevarse a cabo");
                        }
                    }catch(IllegalArgumentException ex){
                        System.out.println(ex.getMessage());
                    }
                break;
                //Opción 5 hacer una retirada en el atributo saldo de un objeto del array.
                case 5:
                    try{
                        numeIBAN= banco.solicitarIBAN();
                        double importe= banco.solicitarImporte();
                        if(banco.retiradaCuenta(numeIBAN, importe)){
                            System.out.println("Retirada realizada con éxito");
                        }else{
                            System.out.println("La retirada no pudo llevarse a cabo");
                        }
                    }catch(IllegalArgumentException ex){
                        System.out.println(ex.getMessage());
                    }
                break;
                //Opción 6 imprimir por pantalla los datos del atributo saldo de un objeto.
                case 6:
                    numeIBAN= banco.solicitarIBAN();
                    banco.mostrarSaldo(numeIBAN);
                break;
                //Opción 7 eliminar una cuenta.
                case 7:
                    numeIBAN= banco.solicitarIBAN();
                    banco.eliminarCuenta(numeIBAN);
                break;
                //Opción 8 finalizar el programa.
                case 8:
                    System.out.println("Gracias por usar nuestro programa.");
                    opcMenu= 9;
                break;
            }
        }while(opcMenu<8);
    } 
}
package prog07_tarea.entidadFinanciera;

import java.util.Scanner;
import prog07_tarea.utilidades.Persona;

/**
 * Clase hija de CuentaBancaria, que además de las cualidaddes heredadas, tiene
 * remuneración y un tipo de interés. Sólo este tipo de cuentas es remunerada.

 */
public class CuentaAhorros extends CuentaBancaria {
    //Atributo de la clase.
    double tipoInteres;
/**
 * Método constructor que permite la creación de objetos de tipo CuentaAhorros.
 * @param titular
 * @param saldo
 * @param numIBAN
 * @param tipoInteres 
 */    
    public CuentaAhorros (Persona titular, double saldo, String numIBAN, double tipoInteres){
        super(titular, saldo, numIBAN);
        this.tipoInteres= tipoInteres;
    }
    
/**
 * Implementación del método alojado en la interfaz Imprimible que recoge en una
 * cadena de caracteres los datos de los atributos de este tipo de cuenta.
 * @return Devuelve una cadena de caracteres.
 */
    @Override
    public String devolverInfoString(){
        String infoCuenta;
        
        infoCuenta= "Titular: " + this.titular.nombre + " " + this.titular.apellidos + " " 
                + this.titular.dni + " -- Saldo: " + this.saldo + " -- IBAN: " + this.numIBAN 
                + " -- Tipo de Interés: " + this.tipoInteres;
        
        return infoCuenta;
    }
/**
 * Método que pide por teclado datos que nos servirán para dar valor a los atributos
 * de un objeto de la clase.
 * Se capturan excepciones por posibles errores en el tipo de dato introducido por teclado.
 * Se utiliza el método validarIBAN de la clase CuentaBancaria, antes de la creación de objetos.
 * Se instancia un objeto Persona, que es atributo de la clase.
 * Se instancia el propio objeto de la clase y se pasan por parámetro los valores recogidos.
 * @return Devuelve un objeto con los valores de sus atributos.
 * En el caso de no ser validado se lanza una excepción controlada que contiene una cadena
 * de caracteres.
 */    
    public static CuentaAhorros pedirDatosObjeto() throws IllegalArgumentException{
        double saldoT;
        double inteT;
        Scanner teclado= new Scanner(System.in);
        System.out.println("Ha escogido Cuenta de Ahorros."
                + "\n Rellene los siguientes datos:");
        System.out.println("Nombre del titular: ");
        String nombreT= teclado.next();
        System.out.println("Apellidos del titular: ");
        String apellT= teclado.next();
        System.out.println("DNI del titular: ");
        String dniT= teclado.next();
        try{
            System.out.println("Saldo inicial en la cuenta: ");
            saldoT= teclado.nextDouble();
        }catch(java.util.InputMismatchException ex){
            throw new IllegalArgumentException("Saldo mal introducido, revísalo.");
        }
        System.out.println("IBAN de la cuenta: ");
        String ibanT= teclado.next();
        try{
        System.out.println("Tipo de interés de la cuenta: ");
        inteT= teclado.nextDouble();
        }catch(java.util.InputMismatchException ex){
            throw new IllegalArgumentException("Tipo de interés mal introducido, revísalo.");
        }
        
        boolean validoParaCrear= CuentaAhorros.validarIBAN(ibanT);
        if(validoParaCrear== true){
            Persona pers= new Persona(nombreT, apellT, dniT);
            CuentaAhorros nuevCuen= new CuentaAhorros(pers, saldoT, ibanT, inteT);
            
            return nuevCuen;
        }else{
            throw new IllegalArgumentException("IBAN introducido de forma incorrecta, vuelva a intentarlo");
        } 
    }
}

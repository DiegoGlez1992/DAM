package MenuOpciones;

/**
 * Clase que define objetos de tipo Opciones de menú. 

 */
public class Opciones {
    int numOpcion;
    String descripOpcion;
    
    public Opciones(int numOp, String descrOp){
        this.numOpcion= numOp;
        this.descripOpcion= descrOp;
    }
}

package MenuOpciones;

import java.util.Scanner;

/**

 */
public class Menu {
    Opciones[] nuevoMenu;
    
    public Menu(Opciones[] nuevasOpc){
        this.nuevoMenu= nuevasOpc;
    }
   
    public void mostrarMenu(){
        System.out.println("Bienvenido a nuestro Menú, dispone de las siguientes opciones:");
        for(int i= 0; i<nuevoMenu.length; i++){
            if(nuevoMenu[i]!= null){ 
            System.out.println(nuevoMenu[i].numOpcion + ". " + nuevoMenu[i].descripOpcion);
            } 
        }
    }
    
    public int solicitarOpcionMenu(){
        System.out.println("Por favor, ingrese la opción deseada");
        Scanner teclado= new Scanner(System.in);
        int opcSel= teclado.nextInt();
        return opcSel;
    }
    

}

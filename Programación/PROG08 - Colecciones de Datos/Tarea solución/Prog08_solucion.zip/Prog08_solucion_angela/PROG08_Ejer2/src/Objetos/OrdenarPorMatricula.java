
package Objetos;

import java.util.Comparator;

/**
 *
 * @author 
 */
public class OrdenarPorMatricula implements Comparator<Vehiculo> {
/**
 * 
 * @param o1
 * @param o2
 * @return 
 */    
    @Override
    public int compare(Vehiculo o1, Vehiculo o2) {
        return o1.matricula.compareTo(o2.matricula);   
    }
}


package Objetos;

import java.util.TreeSet;


/**
 *
 * @author 
 */
public class Concesionario {
/**
 * Para almacenar los objetos de tipo vehículo en una estructura dinámica, he 
 * escogido el TreeSet. Ya que necesitamos ordenar los objetos en base a una 
 * variable concreta (la matrícula)
 */    
    public TreeSet<Vehiculo> conce= new TreeSet<Vehiculo>(new OrdenarPorMatricula());
/**
 * Método que recibe un string matricula por parámetro para localizar un
 * objeto vehículo concreto.
 * @param matric String que se compara con la variable matrícula.
 * @return Devuelve el objeto si el localizado. Si no, devuelve null.
 */    
    public Vehiculo buscarVehiculo(String matric){
        
        for(Vehiculo vh: conce){
            if(matric.equals(vh.matricula)){
                return vh;
            }
        }
        return null;
    }
/**
 * Método que imprime por pantalla los datos de matrícula, marca y precio de un
 * vehículo.
 * @param vh Recibe un objeto de tipo vehículo por parámetro. 
 */    
    public void imprimirVehiculoEncontrado(Vehiculo vh) {
        System.out.println("Vehículo de Matrícula: " + vh.matricula
        + " Marca: " + vh.marca + ", y Precio: " + vh.precio + " €.");
    }
/**
 * Método que imprime por pantalla los datos de matrícula y Km de un
 * vehículo.
 * @param vh Recibe un objeto de tipo vehículo por parámetro.
 */
    public void imprimirVehiculoKm(Vehiculo vh) {
        System.out.println("El vehículo con matrícula " + vh.matricula 
        + " cuenta ahora con: " + vh.numKm + " km.");
    }
/**
 * Método que recibe un nuevo objeto vehículo por parámetro y lo añade a la
 * colección.
 * @param nuevoV Objeto de tipo Vehículo.
 * @return Devuelve true si se ha añadido, o false si no es añadido.
 */    
    public boolean insertarVehiculo(Vehiculo nuevoV){
        return conce.add(nuevoV);
    }
/**
 * Método que imprime por pantalla los valores de cada objeto Vehículo que estén
 * almacenados en la colección en el momento de la consulta.
 * @return Devuelve un valor booleano en el caso de que la colección esté vacía o no.
 */    
    public boolean listarVehiculos() {
        if(!conce.isEmpty()){
            for(Vehiculo vh: conce){
                System.out.println("Vehículo con Marca: " + vh.marca 
                + ", Matrícula: " + vh.matricula 
                + ", Precio: " + vh.precio 
                + ", Kilómetros: " + vh.numKm 
                + ", Descripción: "+ vh.descripcion);
            }
            return true;
        }
        return false;
    }
/**
 * Método que recibe un string matrícula para localizar un objeto vehíuclo dentro
 * de la colección, y un entero km para dar un nuevo valor a la variable Km de 
 * dicho objeto.
 * @param matric Sring matrícula que ayuda a localizar el vehículo.
 * @param km int que da un nuevo valor a la variable Km.
 */    
    public void actualizarKms(String matric, int km){
        for(Vehiculo vh: conce){
            if(matric.equals(vh.matricula)){
                vh.setNumKm(km);
                return;
            }
        }
        System.out.println("No se pudo actualizar Km del vehículo.");
    }
/**
 * Método que localiza un objeto vehículo de la colección por el valor de su
 * matrícula y lo elimina de la colección.
 * @param matric String matricula que recibe el método por parámetro. 
 */    
    public void eliminarVehiculo(String matric){
        for(Vehiculo vh: conce){
            if(matric.equals(vh.matricula)){
                conce.remove(vh);
                System.out.println("Vehículo eliminado.");
                return;
            }
        System.out.println("No existe ningún vehículo con la matrícula "
        + "introducida, no pudo eliminarse vehículo.");
        }
    }
}
    
    
    

/*Clase creada para almacenar atributos de los objetos tipo vehículo*/
package Objetos;

import java.time.LocalDate;
import java.time.Period;

/**
 * @author 
 */
public class Vehiculo {
    //Atributos propios de los objetos de la clase.
    public String marca;
    public String matricula;
    public int numKm;
    public LocalDate fechaMatric;
    public String descripcion;
    public int precio;
    public String nombreProp;
    public String dniProp;
    
    public Vehiculo(String marca, String matricula, int numKm,
        LocalDate fechaMatric, String descripcion, int precio, 
        String nombreProp, String dniProp){
        this.marca= marca;
        this.matricula= matricula;
        this.numKm= numKm;
        this.fechaMatric= fechaMatric;
        this.descripcion= descripcion;
        this.precio= precio;
        this.nombreProp= nombreProp;
        this.dniProp= dniProp;
    }
    
    //Métodos getter y setter para obtener o enviar valores de los atributos.
    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public int getNumKm() {
        return numKm;
    }

    public void setNumKm(int numKm) {
        this.numKm = numKm;
    }

    public LocalDate getFechaMatric() {
        return fechaMatric;
    }

    public void setFechaMatric(LocalDate fechaMatric) {
        this.fechaMatric = fechaMatric;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public String getNombreProp() {
        return nombreProp;
    }

    public void setNombreProp(String nombreProp) {
        this.nombreProp = nombreProp;
    }

    public String getDniProp() {
        return dniProp;
    }

    public void setDniProp(String dniProp) {
        this.dniProp = dniProp;
    }
    
    /*Método para calcular el número de años transcurridos entre la fecha de
    * matriculación y el año actual.
    */
    public static String get_Anios(LocalDate fromDate, LocalDate toDate) {

        Period period = Period.between(fromDate, toDate);
        
        StringBuilder sb = new StringBuilder();
        sb.append(period.getYears()).append(",")
                .append(period.getMonths()).append(",")
                .append(period.getDays());
        return sb.toString();

    }
}

package Operaciones;

import Objetos.Concesionario;
import Objetos.Vehiculo;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author 
 */

public class Principal {  
    
    
    /*Método que ejecuta la salida del menú por pantalla,
    * y recoge el valor de la variable que identifica cada opción de menú.
    */
    public static int interactuarMenu(){
        System.out.println("Menú:" 
        + "\n 1.Nuevo Vehículo."
        + "\n 2.Listar Vehículos."
        + "\n 3.Buscar Vehículo."
        + "\n 4.Modificar kms Vehículo."
        + "\n 5.Eliminar Vehículo."
        + "\n 6.Salir.");

        Scanner teclado= new Scanner(System.in);
        int opcionMenu= teclado.nextInt();

        return opcionMenu;
    }
    

    static boolean validarDatos(String dniProp, String matricula, String nombreProp, Concesionario conces){
        

        Pattern patronDNI= Pattern.compile("([XY]?)([0-9]{1,9})([A-Z]{1})");
        Matcher matchDNI= patronDNI.matcher(dniProp);
        if(!matchDNI.matches()){
            return false;
        }
        
        Pattern patronMatric= Pattern.compile("([0-9]{1,4})([BCDFGHJKLMNÑPQRSTVWXYZ]{1,3})");
        Matcher matchMatric= patronMatric.matcher(matricula);
        if(!matchMatric.matches()){
            return false;
        }
        
       
        if(!nombreProp.contains(" ")){
            return false;
        }
        
        if(nombreProp.length()>40){
            return false;}
        
        //No debe existir un vehículo con la matrícula introducida
        for(Vehiculo vh: conces.conce ){
            if(matricula.equals(vh.matricula)){
                System.out.println("Ya existe un vehículo con la matrícula introducida. Imposible crear nuevo vehículo.");
                return false;
                }else{
                return true;
            }
        }
        return true;
    }
    
    //Método main para ejecutar el programa.
    public static void main(String[] args) {   
        //Instancia del objeto Concesionario.
        Concesionario conce= new Concesionario();
        
    
        Scanner teclado= new Scanner(System.in);
        
        //Variables 
        String temp_marca;
        String temp_matricula;
        int temp_numKm;
        LocalDate temp_fechaMatric;
        String temp_descripcion;
        String temp_nombreProp;
        int temp_precio;
        String temp_dniProp;
        boolean correcto;
 
        System.out.println("Escoja entre las opciones de menú:");
        
        //Bucle donde comienza el menú
        int opcionMenu;
        do{
            opcionMenu= Principal.interactuarMenu();
            switch(opcionMenu){
                case 1:
  
                    try{
                        System.out.println("Por favor, introduzca los datos del nuevo vehículo.");
                        System.out.println("Marca del nuevo vehículo:");
                        temp_marca = teclado.next();
                        teclado.nextLine();
                        System.out.println("Matrícula del nuevo vehículo:");
                        temp_matricula = teclado.next();
                        teclado.nextLine();
                        System.out.println("Número de Km del nuevo vehículo:");
                        temp_numKm = teclado.nextInt();
                        teclado.nextLine();
                        System.out.println("Introduzca la fecha de matriculación del"
                        + "\nnuevo vehículo con formato dd/mm/yyyy");
                        String fecha = teclado.next();
                        DateTimeFormatter df =  DateTimeFormatter.ofPattern("dd/MM/yyyy");
                        String date = fecha;
                        temp_fechaMatric = LocalDate.parse(date, df);
                        System.out.println("Descripción del nuevo vehículo:");
                        temp_descripcion = teclado.next();
                        teclado.nextLine();
                        System.out.println("Precio del nuevo vehículo:");
                        temp_precio = teclado.nextInt();
                        teclado.nextLine();
                        System.out.println("Nombre del propietario del nuevo vehículo:");
                        temp_nombreProp = teclado.nextLine();
                        System.out.println("DNI del propietario del nuevo vehículo:");
                        temp_dniProp = teclado.next();
                        teclado.nextLine();
                    
                        correcto = Principal.validarDatos(temp_dniProp, temp_matricula, temp_nombreProp, conce);

                        if(correcto){
                     
                            Vehiculo nuevoVeh= new Vehiculo(temp_marca, temp_matricula, 
                                temp_numKm, temp_fechaMatric, temp_descripcion, 
                                temp_precio, temp_nombreProp, temp_dniProp);

                            conce.insertarVehiculo(nuevoVeh);

                            System.out.println("Se ha creado el nuevo vehículo.");
                        }else{
                            System.out.println("Alguno de los datos introducidos es incorrecto."
                                + "\nPor favor, revíselo e inténtelo de nuevo.");
                        }
                    }catch(java.util.InputMismatchException exc1){
                        System.out.println("Alguno de los datos tiene un formato incorrecto, vuelva a intentarlo.\n");
                    }catch(java.time.format.DateTimeParseException exc2){
                        System.out.println("Alguno de los datos tiene un formato incorrecto, vuelva a intentarlo.\n");
                    }
                break;
                
                case 2:
            
                    if(!conce.listarVehiculos()){
                        System.out.println("No existen vehículos en la base de datos.");
                    }
                break;
                
                case 3:
                    System.out.println("Introduzca la matrícula del vehículo que desea encontrar:");
                    temp_matricula = teclado.next();
                    teclado.nextLine();
                    try{     
                        conce.imprimirVehiculoEncontrado(conce.buscarVehiculo(temp_matricula));
                    }catch(java.lang.NullPointerException exc4){
                        System.out.println("No existe ningún vehículo con la matrícula introducida.");
                    }
                break;
                
                case 4:
                    System.out.println("Introduzca la matrícula del vehículo cuyos kilómetros desea actualizar:");
                    temp_matricula = teclado.next();
                    teclado.nextLine();
                    System.out.println("Introduzca el nuevo valor para los kilómetros:");
                    temp_numKm = teclado.nextInt();
                    teclado.nextLine();
                    try{     
                        conce.actualizarKms(temp_matricula, temp_numKm);
                        conce.imprimirVehiculoKm(conce.buscarVehiculo(temp_matricula));
                    }catch(java.lang.NullPointerException exc5){
                        System.out.println("No existe ningún vehículo con la matrícula introducida.");
                    }
                break;
                
                case 5:
                    System.out.println("Introduzca la matrícula del vehículo que quiere eliminar:");
                    temp_matricula = teclado.next();
                    teclado.nextLine();
                    conce.eliminarVehiculo(temp_matricula);
                break;
                
                case 6:
                    System.out.println("Gracias por usar nuestra aplicación.");
                    opcionMenu= 7;
                break;
            }
        }while(opcionMenu<6);
    }
}

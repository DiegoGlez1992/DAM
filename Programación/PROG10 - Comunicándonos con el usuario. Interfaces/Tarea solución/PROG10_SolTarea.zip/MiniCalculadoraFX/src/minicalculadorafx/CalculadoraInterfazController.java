/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package minicalculadorafx;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;
import javafx.fxml.FXML;

/**
 * FXML Controller class
 *
 * @author
 */
public class CalculadoraInterfazController implements Initializable {

    Double acumulado = 0.0;

    String oper1 = "";

    int operacion = 0;

    @FXML
    private TextField pantalla;

    @FXML
    private void buttonSumarHandler(ActionEvent event) {
        if (!"".equals(oper1)) {
            acumulado = acumulado + Double.valueOf(oper1);
        }
        oper1 = "";
        operacion = 1;
        pantalla.setText("");
    }

    @FXML
    private void buttonRestarHandler(ActionEvent event) {
        if (!"".equals(oper1)) {
            if (acumulado!=0.0)
                acumulado = acumulado - Double.valueOf(oper1);
            else acumulado=Double.valueOf(oper1);
        }
        oper1 = "";
        operacion = 2;
        pantalla.setText("");
    }

    @FXML
    private void buttonMultiplicarHandler(ActionEvent event) {
        if (!"".equals(oper1)) {
            if (acumulado!=0)
                acumulado = acumulado * Double.valueOf(oper1);
            else acumulado=Double.valueOf(oper1);
        }
        oper1 = "";
        operacion = 3;
        pantalla.setText("");
    }

    @FXML
    private void buttonDividirHandler(ActionEvent event) {
        if (!"".equals(oper1)) {
            if (acumulado!=0)
                acumulado = acumulado / Double.valueOf(oper1);
            else acumulado=Double.valueOf(oper1);
        }
        oper1 = "";
        operacion = 4;
        pantalla.setText("");
    }

    @FXML
    private void buttonOneHandler(ActionEvent event) {
        oper1 = oper1 + "1";
        pantalla.setText(oper1);
    }

    @FXML
    private void buttonZeroHandler(ActionEvent event) {
        oper1 = oper1 + "0";
        pantalla.setText(oper1);
    }

    @FXML
    private void buttonTwoHandler(ActionEvent event) {
        oper1 = oper1 + "2";
        pantalla.setText(oper1);
    }

    @FXML
    private void buttonThreeHandler(ActionEvent event) {
        oper1 = oper1 + "3";
        pantalla.setText(oper1);
    }

    @FXML
    private void buttonFourHandler(ActionEvent event) {
        oper1 = oper1 + "4";
        pantalla.setText(oper1);
    }

    @FXML
    private void buttonFiveHandler(ActionEvent event) {
        oper1 = oper1 + "5";
        pantalla.setText(oper1);
    }

    @FXML
    private void buttonSixHandler(ActionEvent event) {
        oper1 = oper1 + "6";
        pantalla.setText(oper1);
    }

    @FXML
    private void buttonSevenHandler(ActionEvent event) {
        oper1 = oper1 + "7";
        pantalla.setText(oper1);
    }

    @FXML
    private void buttonEigthHandler(ActionEvent event) {
        oper1 = oper1 + "8";
        pantalla.setText(oper1);
    }

    @FXML
    private void buttonNineHandler(ActionEvent event) {
        oper1 = oper1 + "9";
        pantalla.setText(oper1);
    }
    
    @FXML
    private void buttonCEHandler(ActionEvent event) {
        acumulado=0.0;
        pantalla.setText("");
        operacion=0;
    }

    @FXML
    private void buttonResultadoHandler(ActionEvent event) {

        switch (operacion) {
            case 1:
                acumulado = acumulado + Double.valueOf(oper1);
                oper1 = "";
                operacion = 0;
                pantalla.setText(Double.toString(acumulado));
                break;
            case 2:
                acumulado = acumulado - Double.valueOf(oper1);
                oper1 = "";
                operacion = 0;
                pantalla.setText(Double.toString(acumulado));
                break;
            case 3:
                acumulado = acumulado * Double.valueOf(oper1);
                oper1 = "";
                operacion = 0;
                pantalla.setText(Double.toString(acumulado));
                break;
            case 4:
                acumulado = acumulado / Double.valueOf(oper1);
                oper1 = "";
                operacion = 0;
                pantalla.setText(Double.toString(acumulado));
                break;
        }
        
        pantalla.setText(Double.toString(acumulado));

    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package escritor;
/**
 *
 * @author usuario
 */
public class Main {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Lo único que hacemos es escribir los números de 0 a 9 en
        // la salida estándar del proceso
        for (int i=0; i<10; i++)
            System.out.println(i);
    }

}
